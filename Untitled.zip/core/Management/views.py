from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from .models import User

def home(request):
    return render(request,'logpag.html')


def managementlogin(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        try:
            user=User.objects.get(username=username)
        except:
            return render(request,'logpag.html',{"error":"User Does't exisit "})
        if user.is_staff==True:
            user=authenticate(username=username,password=password)
            print()
            if user is not None:
                print("yes")
                return render(request,'f1.html')
            else:
                return render(request,'logpag.html',{"error":"Wrong credentials"})
        else:
                return render(request,'logpag.html',{"error":"Not allowed"})
    return render(request,'logpag.html')

def patientlogin(request):
    if request.method=="POST":
        username=request.POST.get("username1")
        password=request.POST.get("password1")
        try:
            user=User.objects.get(username=username)
        except:
            return render(request,'logpag.html',{"error":"User Does't exisit "})
        if user.is_paitent==True or user.is_staff==True:
            passw=user.password
            user=authenticate(username=username,password=password)
            if user is not None or passw==password:
                return render(request,'f2.html')
            else:
                return render(request,'logpag.html',{"error":"Wrong credentials"})
        else:
                return render(request,'logpag.html',{"error":"Not allowed"})
    return render(request,'logpag.html')


def createpatient(request):
    if request.method=="POST":
        try:
            username=request.POST.get("username")
            password=request.POST.get("password")
            gender=request.POST.get("gender")
            mobile=request.POST.get("mobileno")
            email=request.POST.get("email")
            dob=request.POST.get("dob")
            blood=request.POST.get("blood")
            address=request.POST.get("address")
            User.objects.create(username=username,password=password,gender=gender,email=email,Mobile=mobile,dob=dob,bloodgroup=blood,address=address,is_paitent=True)
            return redirect('home')
        except:
            return render(request,"createuser.html",{"error":"Try to change username!!"})
    return render(request,"createuser.html")