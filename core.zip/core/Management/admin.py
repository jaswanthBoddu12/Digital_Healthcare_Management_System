from django.contrib import admin
from .models import User,Record


admin.site.register(User)
admin.site.register(Record)